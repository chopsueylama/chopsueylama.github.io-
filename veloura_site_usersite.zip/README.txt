How to deploy to GitHub Pages (User Site)
------------------------------------------
1) Create a repository named: chopsueylama.github.io
2) Upload ALL files from this folder into the repo root (not in a subfolder).
3) Go to Settings → Pages → Source: Deploy from a branch → Branch: main / (root).
4) Your site will be live at: https://chopsueylama.github.io/
Notes:
- All image paths are relative (e.g., assets/<slug>/set1.png) so they work locally and on Pages.
